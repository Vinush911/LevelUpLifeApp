import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart'; // For TimeOfDay

class TimetableEntry {
  final String id;
  final String title;
  final int startTimeMinutes; // Minutes since midnight (0-1439)
  final int endTimeMinutes;   // Minutes since midnight (0-1439)
  final List<String> repeatDays; // e.g., ['Mon', 'Wed', 'Fri'] or empty if not repeating

  // --- Ensure these fields exist ---
  final bool reminderEnabled;
  final int reminderTimeOffsetMinutes; // e.g., 5, 10, 15, 30 minutes before
  final int? notificationId; // Store the ID used for scheduling

  TimetableEntry({
    required this.id,
    required this.title,
    required this.startTimeMinutes,
    required this.endTimeMinutes,
    required this.repeatDays,
    // --- Ensure these are in the constructor ---
    required this.reminderEnabled,
    required this.reminderTimeOffsetMinutes,
    this.notificationId,
  });

  // Helper to get TimeOfDay from minutes
  TimeOfDay get startTime => TimeOfDay(hour: startTimeMinutes ~/ 60, minute: startTimeMinutes % 60);
  TimeOfDay get endTime => TimeOfDay(hour: endTimeMinutes ~/ 60, minute: endTimeMinutes % 60);

  factory TimetableEntry.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return TimetableEntry(
      id: doc.id,
      title: data['title'] ?? 'Untitled Entry',
      startTimeMinutes: (data['startTimeMinutes'] as num? ?? 0).toInt(),
      endTimeMinutes: (data['endTimeMinutes'] as num? ?? 0).toInt(),
      repeatDays: List<String>.from(data['repeatDays'] ?? []),
      // --- Ensure these are read from Firestore ---
      reminderEnabled: data['reminderEnabled'] ?? false,
      reminderTimeOffsetMinutes: (data['reminderTimeOffsetMinutes'] as num? ?? 15).toInt(),
      notificationId: (data['notificationId'] as num?)?.toInt(), // Read ID if exists
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'startTimeMinutes': startTimeMinutes,
      'endTimeMinutes': endTimeMinutes,
      'repeatDays': repeatDays,
      // --- Ensure these are added to the map ---
      'reminderEnabled': reminderEnabled,
      'reminderTimeOffsetMinutes': reminderTimeOffsetMinutes,
      'notificationId': notificationId, // Store ID
    };
  }
}

