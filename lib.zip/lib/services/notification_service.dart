import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
// --- Ensure this package was fetched by 'pub get' AND your IDE recognizes it ---
import 'package:flutter_native_timezone_updated_gradle/flutter_native_timezone.dart';
// --- Necessary Imports ---
import 'package:intl/intl.dart'; // For DateFormat
import '../models/timetable_entry.dart'; // For TimetableEntry
import 'dart:math'; // For Random
// --- Removed dart:html import ---

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
  FlutterLocalNotificationsPlugin();

  bool _initialized = false;
  bool _notificationsEnabled = false;

  Future<void> initialize() async {
    if (_initialized) return;

    try {
      tz.initializeTimeZones();
      // Use the imported package name correctly
      final String currentTimeZone = await FlutterNativeTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(currentTimeZone));
    } catch (e) {
      debugPrint("Error initializing timezone: $e");
    }

    const AndroidInitializationSettings initializationSettingsAndroid =
    AndroidInitializationSettings('@mipmap/ic_launcher'); // Make sure this icon exists

    final DarwinInitializationSettings initializationSettingsIOS =
    DarwinInitializationSettings(
      requestAlertPermission: false, // Request permissions explicitly later
      requestBadgePermission: false,
      requestSoundPermission: false,
      onDidReceiveLocalNotification: onDidReceiveLocalNotification,
    );

    final InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
    );

    // Initialize the plugin
    await flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: onDidReceiveNotificationResponse,
      onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
    );

    _initialized = true;
    debugPrint("NotificationService Initialized");
    // Request permissions after basic initialization
    await requestPermissions();
  }

  Future<void> requestPermissions() async {
    if (!_initialized) {
      debugPrint("NotificationService not initialized before requesting permissions.");
      return;
    }
    try {
      // iOS specific permission request
      final bool? resultIOS = await flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<
          IOSFlutterLocalNotificationsPlugin>()
          ?.requestPermissions(
        alert: true,
        badge: true,
        sound: true,
      );
      _notificationsEnabled = resultIOS ?? false; // Update status based on iOS result

      // Android specific permission request (API 33+)
      final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
      flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      if (androidImplementation != null) {
        // Request notification permission specifically on Android 13+
        final bool? resultAndroid = await androidImplementation.requestNotificationsPermission();
        // If Android result is available, use it. Otherwise keep iOS result (or default false)
        _notificationsEnabled = resultAndroid ?? _notificationsEnabled;
      }

      debugPrint("Notification permissions enabled: $_notificationsEnabled");

    } catch (e) {
      debugPrint("Error requesting notification permissions: $e");
      _notificationsEnabled = false; // Assume disabled on error
    }
  }

  // Getter to check if notifications are allowed
  bool get areNotificationsEnabled => _notificationsEnabled;


  // --- Scheduling Logic ---
  Future<int?> scheduleNotificationForEntry(TimetableEntry entry) async {
    if (!_initialized || !_notificationsEnabled) {
      debugPrint("Cannot schedule notification: Service not initialized or permissions denied.");
      return null;
    }
    // Don't schedule if reminder isn't enabled or offset is invalid
    if (!entry.reminderEnabled || entry.reminderTimeOffsetMinutes <= 0) {
      // Also cancel any previously scheduled notification for this entry if reminder is now disabled
      await cancelNotification(entry.notificationId);
      return null;
    }

    final now = tz.TZDateTime.now(tz.local);
    final List<int> scheduledIds = []; // Keep track of IDs actually scheduled
    final Random random = Random();

    // Determine the base ID: use the one stored in the entry if it exists, otherwise generate one.
    // NOTE: Generating random IDs makes it harder to reliably cancel *all* notifications for an edited entry.
    // Storing the base ID in Firestore (as done in edit_timetable_entry_screen) is better.
    final int baseNotificationId = entry.notificationId ?? random.nextInt(214748364); // Use stored or generate positive int


    if (entry.repeatDays.isNotEmpty) {
      int scheduleCount = 0;
      // Limit how far in the future we schedule repeating notifications (e.g., 2 weeks)
      // For true indefinite repeats, a background task or rescheduling on app open is needed.
      final maxSchedulesPerEntry = 14;

      // Check upcoming days
      for (int i = 0; i < maxSchedulesPerEntry * 7 && scheduleCount < maxSchedulesPerEntry ; i++) {
        final checkDate = now.add(Duration(days: i));
        final dayName = DateFormat('E').format(checkDate); // 'Mon', 'Tue', etc.

        // If the checkDate's weekday is one of the repeating days
        if (entry.repeatDays.contains(dayName)) {
          // Calculate the exact date and time for the reminder
          final tz.TZDateTime scheduledNotificationDateTime = tz.TZDateTime(
            tz.local,
            checkDate.year,
            checkDate.month,
            checkDate.day,
            entry.startTime.hour, // Get hour from TimeOfDay getter
            entry.startTime.minute, // Get minute from TimeOfDay getter
          ).subtract(Duration(minutes: entry.reminderTimeOffsetMinutes)); // Subtract offset

          // Only schedule if the calculated reminder time is in the future
          if (scheduledNotificationDateTime.isAfter(now)) {
            // Generate a unique ID for this specific instance of the repeating notification
            // Combine base ID with date/time components. Ensure it fits in 32-bit int.
            // Use modulo to keep it within range, less likely to collide but not guaranteed unique forever.
            final int instanceNotificationId = (baseNotificationId + checkDate.millisecondsSinceEpoch ~/ 100000) % 2147483647;

            await _zonedScheduleNotification(
              id: instanceNotificationId,
              title: entry.title,
              // Format the *actual start time* for the notification body
              body: "Starts at ${DateFormat.jm().format(DateTime(now.year, now.month, now.day, entry.startTime.hour, entry.startTime.minute))}",
              scheduledDate: scheduledNotificationDateTime,
            );
            scheduledIds.add(instanceNotificationId);
            scheduleCount++;
          }
        }
      }
    } else {
      // --- Handle non-repeating events ---
      // This part still requires the TimetableEntry model to store the specific DATE of the event.
      // Assuming 'eventDate' is a DateTime field added to TimetableEntry:
      // final DateTime eventDate = entry.eventDate ?? DateTime.now(); // Replace with actual date logic

      // --- Placeholder: Using today's date for non-repeating events ---
      // This means non-repeating events will only trigger a reminder if scheduled for today.
      final DateTime eventDate = DateTime(now.year, now.month, now.day); // Use today

      final tz.TZDateTime scheduledNotificationDateTime = tz.TZDateTime(
        tz.local,
        eventDate.year,
        eventDate.month,
        eventDate.day,
        entry.startTime.hour,
        entry.startTime.minute,
      ).subtract(Duration(minutes: entry.reminderTimeOffsetMinutes));

      // Only schedule if the reminder time is in the future
      if (scheduledNotificationDateTime.isAfter(now)) {
        await _zonedScheduleNotification(
          id: baseNotificationId, // Use the base ID for non-repeating
          title: entry.title,
          body: "Starts at ${DateFormat.jm().format(DateTime(now.year, now.month, now.day, entry.startTime.hour, entry.startTime.minute))}",
          scheduledDate: scheduledNotificationDateTime,
        );
        scheduledIds.add(baseNotificationId);
      }
    }
    // Return the base ID that was used (or generated) for scheduling.
    // This should be stored back into the TimetableEntry in Firestore.
    return scheduledIds.isNotEmpty ? baseNotificationId : null;
  }

  // Helper method to actually schedule using the plugin
  Future<void> _zonedScheduleNotification({
    required int id,
    required String title,
    required String body,
    required tz.TZDateTime scheduledDate,
  }) async {
    try {
      await flutterLocalNotificationsPlugin.zonedSchedule(
        id,
        title,
        body,
        scheduledDate,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'timetable_channel_id', // Channel ID
            'Timetable Reminders',    // Channel Name
            channelDescription: 'Notifications for upcoming timetable events', // Channel Description
            importance: Importance.max,
            priority: Priority.high,
            // icon: 'app_icon', // Optional: if you have a specific notification icon
          ),
          iOS: DarwinNotificationDetails(
            presentAlert: true, // Show alert when app is foreground
            presentBadge: true, // Update app badge count
            presentSound: true, // Play sound
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle, // Crucial for timely notifications
        uiLocalNotificationDateInterpretation:
        UILocalNotificationDateInterpretation.absoluteTime, // Use absolute time
        // Use matchDateTimeComponents ONLY for system-managed weekly repeats, not custom loops
        // matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
      );
      debugPrint("Scheduled notification ID $id for $scheduledDate");
    } catch(e) {
      debugPrint("Error scheduling notification ID $id: $e");
    }
  }


  // --- Cancellation Logic ---
  Future<void> cancelNotification(int? notificationId) async {
    if (!_initialized) return;
    if (notificationId != null) {
      try {
        await flutterLocalNotificationsPlugin.cancel(notificationId);
        debugPrint("Cancelled notification ID $notificationId");
        // IMPORTANT for repeating: Cancelling the base ID only cancels non-repeating
        // or potentially the *next* system-managed repeat.
        // For the loop-based scheduling above, you need to cancel *all* related instance IDs.
        // This requires storing them or querying pending notifications.
        // For now, this only cancels the specific ID passed.
        // Consider calling cancelAll() before rescheduling an edited repeating event.
      } catch (e) {
        debugPrint("Error cancelling notification ID $notificationId: $e");
      }
    }
  }

  Future<void> cancelAllNotifications() async {
    if (!_initialized) return;
    try {
      await flutterLocalNotificationsPlugin.cancelAll();
      debugPrint("Cancelled ALL notifications");
    } catch(e) {
      debugPrint("Error cancelling all notifications: $e");
    }
  }

  // --- Callbacks ---
  // Called when notification is received while app is in foreground (older iOS only)
  void onDidReceiveLocalNotification(
      int id, String? title, String? body, String? payload) async {
    debugPrint("iOS Foreground Notification Received: $id");
    // Display an in-app message or dialog if desired
  }

  // Called when user taps notification (app foreground or background)
  void onDidReceiveNotificationResponse(NotificationResponse notificationResponse) async {
    final String? payload = notificationResponse.payload; // Optional data passed when scheduling
    debugPrint('Notification tapped with payload: $payload');
    // TODO: Add navigation logic based on payload if needed
    // e.g., if (payload == 'timetable_event') { navigateToTimetable(); }
  }
}

// Top-level function required for background handling on Android
@pragma('vm:entry-point')
void notificationTapBackground(NotificationResponse notificationResponse) {
  // Handle notification tap when app is terminated
  // Initialize plugins/services carefully if needed here (limited capability)
  debugPrint('Notification tapped in background/terminated with payload: ${notificationResponse.payload}');
  // Cannot directly interact with Flutter UI here. Can perform background tasks.
}

