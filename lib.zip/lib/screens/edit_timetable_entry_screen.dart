import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/timetable_entry.dart';
// Removed intl import as it's not directly used here for formatting anymore

class EditTimetableEntryScreen extends StatefulWidget {
  final String uid;
  final TimetableEntry? entry; // Null if creating new

  // --- FIX: Removed selectedDate parameter ---
  const EditTimetableEntryScreen({super.key, required this.uid, this.entry});

  @override
  State<EditTimetableEntryScreen> createState() => _EditTimetableEntryScreenState();
}

class _EditTimetableEntryScreenState extends State<EditTimetableEntryScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  TimeOfDay? _startTime;
  TimeOfDay? _endTime;
  final List<bool> _selectedDays = List.filled(7, false); // Mon to Sun
  final List<String> _dayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.entry != null) {
      _titleController.text = widget.entry!.title;
      _startTime = widget.entry!.startTime;
      _endTime = widget.entry!.endTime;
      for (var day in widget.entry!.repeatDays) {
        final index = _dayLabels.indexOf(day);
        if (index != -1) {
          _selectedDays[index] = true;
        }
      }
    } else {
      // Default times for new entry
      _startTime = const TimeOfDay(hour: 9, minute: 0);
      _endTime = const TimeOfDay(hour: 10, minute: 0);
      // --- If you wanted to use a selectedDate passed from the previous screen ---
      // final initialDate = widget.selectedDate ?? DateTime.now(); // Example if selectedDate existed
      // _startTime = TimeOfDay(hour: 9, minute: 0); // Default time
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  Future<void> _selectTime(BuildContext context, bool isStartTime) async {
    final initialTime = (isStartTime ? _startTime : _endTime) ?? TimeOfDay.now();
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: initialTime,
    );
    if (picked != null) {
      setState(() {
        if (isStartTime) {
          _startTime = picked;
          // Auto-adjust end time if it's before or same as start time
          if (_endTime != null &&
              (picked.hour * 60 + picked.minute) >=
                  (_endTime!.hour * 60 + _endTime!.minute)) {
            int newHour = picked.hour + 1;
            int newMinute = picked.minute;
            if (newHour >= 24) { // Handle wrap around midnight
              newHour = 23;
              newMinute = 59; // Set to end of day if wraps past midnight
            }
            _endTime = TimeOfDay(hour: newHour, minute: newMinute);
          }
        } else {
          _endTime = picked;
          // Auto-adjust start time if it's after or same as end time
          if (_startTime != null &&
              (_startTime!.hour * 60 + _startTime!.minute) >=
                  (picked.hour * 60 + picked.minute)) {
            int newHour = picked.hour - 1;
            int newMinute = picked.minute;
            if (newHour < 0) { // Handle going before midnight
              newHour = 0;
              newMinute = 0; // Set to start of day if wraps before midnight
            }
            _startTime = TimeOfDay(hour: newHour, minute: newMinute);
          }
        }
      });
    }
  }

  Future<void> _saveEntry() async {
    if (!_formKey.currentState!.validate() || _startTime == null || _endTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all fields and select times.'), backgroundColor: Colors.orange),
      );
      return;
    }

    final title = _titleController.text.trim();
    final startTimeMinutes = _startTime!.hour * 60 + _startTime!.minute;
    final endTimeMinutes = _endTime!.hour * 60 + _endTime!.minute;

    if (endTimeMinutes <= startTimeMinutes) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('End time must be after start time.'), backgroundColor: Colors.orange),
      );
      return;
    }

    final List<String> repeatDays = [];
    for (int i = 0; i < _selectedDays.length; i++) {
      if (_selectedDays[i]) {
        repeatDays.add(_dayLabels[i]);
      }
    }

    setState(() => _isLoading = true);

    final firestore = FirebaseFirestore.instance;
    final collectionRef = firestore.collection('users').doc(widget.uid).collection('timetable_entries');

    final data = {
      'title': title,
      'startTimeMinutes': startTimeMinutes,
      'endTimeMinutes': endTimeMinutes,
      'repeatDays': repeatDays,
      // 'reminderEnabled': false, // Add default if uncommenting model field
      // 'reminderTimeOffsetMinutes': 15, // Add default if uncommenting model field
    };

    try {
      if (widget.entry == null) {
        // Create new
        await collectionRef.add(data);
      } else {
        // Update existing
        await collectionRef.doc(widget.entry!.id).update(data);
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      debugPrint("Error saving timetable entry: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error saving entry: $e"), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final localizations = MaterialLocalizations.of(context); // For time formatting

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.entry == null ? "Add Timetable Entry" : "Edit Entry"),
        actions: [
          IconButton(
            icon: _isLoading ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save),
            onPressed: _isLoading ? null : _saveEntry,
            tooltip: "Save Entry",
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: "Event Title"),
                validator: (value) => (value == null || value.trim().isEmpty) ? 'Please enter a title' : null,
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Start Time"),
                      TextButton(
                        onPressed: () => _selectTime(context, true),
                        child: Text(
                          _startTime != null ? localizations.formatTimeOfDay(_startTime!) : 'Select Time',
                          style: const TextStyle(fontSize: 18),
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("End Time"),
                      TextButton(
                        onPressed: () => _selectTime(context, false),
                        child: Text(
                          _endTime != null ? localizations.formatTimeOfDay(_endTime!) : 'Select Time',
                          style: const TextStyle(fontSize: 18),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const Text("Repeat On: (Leave blank for one-time event)"),
              const SizedBox(height: 8),
              ToggleButtons(
                isSelected: _selectedDays,
                onPressed: (int index) {
                  setState(() {
                    _selectedDays[index] = !_selectedDays[index];
                  });
                },
                borderRadius: BorderRadius.circular(8),
                constraints: const BoxConstraints(minHeight: 40.0, minWidth: 45.0),
                children: _dayLabels.map((day) => Text(day)).toList(),
              ),
              const SizedBox(height: 30),
              // Reminder options can be added back here later
            ],
          ),
        ),
      ),
    );
  }
}
