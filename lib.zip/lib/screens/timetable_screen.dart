import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';
import '../models/timetable_entry.dart';
import 'edit_timetable_entry_screen.dart';
import 'dart:collection'; // For LinkedHashMap

class TimetableScreen extends StatefulWidget {
  final String uid;
  const TimetableScreen({super.key, required this.uid});

  @override
  State<TimetableScreen> createState() => _TimetableScreenState();
}

class _TimetableScreenState extends State<TimetableScreen> {
  CalendarFormat _calendarFormat = CalendarFormat.week;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  List<TimetableEntry> _selectedEvents = [];

  // Groups events by date, handling repeats
  LinkedHashMap<DateTime, List<TimetableEntry>> _groupEvents(List<QueryDocumentSnapshot> docs) {
    final events = LinkedHashMap<DateTime, List<TimetableEntry>>(
      equals: isSameDay,
      hashCode: getHashCode,
    );

    for (var doc in docs) {
      final entry = TimetableEntry.fromFirestore(doc);
      // Use TimeOfDay directly for calculations if needed, but primarily use minutes
      final repeatDays = entry.repeatDays;

      // Add event for the specific start date if it doesn't repeat
      if (repeatDays.isEmpty) {
        // --- Requires Date Handling for Non-Repeating ---
        // TODO: Implement proper date storage/retrieval for non-repeating events.
        // For now, it won't show non-repeating events unless logic is added here.
        // Example: If you add a 'eventDate' Timestamp field to TimetableEntry:
        // if (entry.eventDate != null) {
        //   final eventDateTime = entry.eventDate!.toDate();
        //   final dateKey = DateTime.utc(eventDateTime.year, eventDateTime.month, eventDateTime.day);
        //   (events[dateKey] ??= []).add(entry);
        // }
        // --- End TODO ---
      }
      // If it repeats, add it for relevant days within a range
      else {
        final today = DateTime.now();
        // Go back roughly a year for past occurrences
        final rangeStart = DateTime.utc(today.year -1 , today.month, today.day);
        // Go forward roughly a year for future occurrences
        final rangeEnd = DateTime.utc(today.year + 1, today.month, today.day);

        DateTime checkDate = rangeStart;
        while(checkDate.isBefore(rangeEnd) || isSameDay(checkDate, rangeEnd)){ // Include rangeEnd
          final dayOfWeek = DateFormat('E').format(checkDate); // 'Mon', 'Tue', etc.
          if(repeatDays.contains(dayOfWeek)){
            final dateKey = DateTime.utc(checkDate.year, checkDate.month, checkDate.day);

            // --- FIX: Pass ALL required parameters from the original entry ---
            final displayEntry = TimetableEntry(
                id: entry.id,
                title: entry.title,
                startTimeMinutes: entry.startTimeMinutes,
                endTimeMinutes: entry.endTimeMinutes,
                repeatDays: entry.repeatDays,
                // Pass reminder info from the original entry
                reminderEnabled: entry.reminderEnabled,
                reminderTimeOffsetMinutes: entry.reminderTimeOffsetMinutes,
                notificationId: entry.notificationId // Pass existing ID if needed elsewhere
            );
            // --- END FIX ---
            (events[dateKey] ??= []).add(displayEntry);
          }
          checkDate = checkDate.add(const Duration(days: 1));
        }
      }
    }
    return events;
  }

  List<TimetableEntry> _getEventsForDay(DateTime day, Map<DateTime, List<TimetableEntry>> groupedEvents) {
    // Return events for the day (using UTC for consistency with keys)
    final events = groupedEvents[DateTime.utc(day.year, day.month, day.day)] ?? [];
    // Sort events by start time for display
    events.sort((a, b) => a.startTimeMinutes.compareTo(b.startTimeMinutes));
    return events;
  }

  // Function used by table_calendar hashCode
  int getHashCode(DateTime key) {
    return key.day * 1000000 + key.month * 10000 + key.year;
  }

  @override
  void initState() {
    super.initState();
    _selectedDay = _focusedDay;
    // Initial fetch happens in StreamBuilder
  }

  // Helper to convert TimeOfDay to DateTime for formatting
  DateTime _combineDateAndTime(DateTime date, TimeOfDay time) {
    return DateTime(date.year, date.month, date.day, time.hour, time.minute);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Timetable")),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc(widget.uid)
            .collection('timetable_entries')
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final groupedEvents = _groupEvents(snapshot.data!.docs);
          _selectedEvents = _getEventsForDay(_selectedDay ?? _focusedDay, groupedEvents);

          return Column(
            children: [
              TableCalendar<TimetableEntry>(
                firstDay: DateTime.utc(DateTime.now().year - 2, 1, 1),
                lastDay: DateTime.utc(DateTime.now().year + 2, 12, 31),
                focusedDay: _focusedDay,
                selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                calendarFormat: _calendarFormat,
                eventLoader: (day) => _getEventsForDay(day, groupedEvents),
                startingDayOfWeek: StartingDayOfWeek.monday,
                calendarStyle: const CalendarStyle(
                  outsideDaysVisible: false,
                  todayDecoration: BoxDecoration(
                    color: Colors.purpleAccent,
                    shape: BoxShape.circle,
                  ),
                  selectedDecoration: BoxDecoration(
                    color: Colors.deepPurple,
                    shape: BoxShape.circle,
                  ),
                ),
                onDaySelected: (selectedDay, focusedDay) {
                  if (!isSameDay(_selectedDay, selectedDay)) {
                    setState(() {
                      _selectedDay = selectedDay;
                      _focusedDay = focusedDay;
                      _selectedEvents = _getEventsForDay(selectedDay, groupedEvents);
                    });
                  }
                },
                onFormatChanged: (format) {
                  if (_calendarFormat != format) {
                    setState(() {
                      _calendarFormat = format;
                    });
                  }
                },
                onPageChanged: (focusedDay) {
                  setState(() {
                    _focusedDay = focusedDay;
                    // Update selected day if it moves off-screen during page change
                    // Determine the first visible day of the new focused page/week
                    DateTime firstVisibleDay;
                    if (_calendarFormat == CalendarFormat.month) {
                      firstVisibleDay = DateTime.utc(focusedDay.year, focusedDay.month, 1);
                    } else { // week or twoWeeks
                      firstVisibleDay = focusedDay.subtract(Duration(days: focusedDay.weekday - DateTime.monday));
                    }
                    // Determine the last visible day
                    DateTime lastVisibleDay;
                    if (_calendarFormat == CalendarFormat.month) {
                      lastVisibleDay = DateTime.utc(focusedDay.year, focusedDay.month + 1, 0);
                    } else if (_calendarFormat == CalendarFormat.twoWeeks){
                      lastVisibleDay = firstVisibleDay.add(const Duration(days: 13));
                    } else { // week
                      lastVisibleDay = firstVisibleDay.add(const Duration(days: 6));
                    }

                    if (_selectedDay != null &&
                        (_selectedDay!.isBefore(firstVisibleDay) ||
                            _selectedDay!.isAfter(lastVisibleDay))) {
                      _selectedDay = focusedDay; // Select the new focused day
                      _selectedEvents = _getEventsForDay(_selectedDay!, groupedEvents);
                    }
                  });
                },
                headerStyle: const HeaderStyle(
                  formatButtonVisible: true,
                  titleCentered: true,
                ),
              ),
              const SizedBox(height: 8.0),
              Expanded(
                child: _selectedEvents.isEmpty
                    ? Center(child: Text("No events for ${DateFormat.yMMMd().format(_selectedDay ?? _focusedDay)}"))
                    : ListView.builder(
                  itemCount: _selectedEvents.length,
                  itemBuilder: (context, index) {
                    final event = _selectedEvents[index];
                    final startTimeFormatted = DateFormat.jm().format(_combineDateAndTime(_selectedDay ?? DateTime.now(), event.startTime));
                    final endTimeFormatted = DateFormat.jm().format(_combineDateAndTime(_selectedDay ?? DateTime.now(), event.endTime));
                    return ListTile(
                      title: Text(event.title),
                      subtitle: Text('$startTimeFormatted - $endTimeFormatted'),
                      // Show reminder icon if enabled
                      trailing: event.reminderEnabled ? const Icon(Icons.notifications_active, color: Colors.blueAccent, size: 18) : null,
                      onTap: () {
                        // Find the original document from the snapshot to pass for editing
                        final originalDoc = snapshot.data!.docs.firstWhere(
                                (doc) => doc.id == event.id,
                            // Provide a fallback or handle case where doc might not be found
                            orElse: () => snapshot.data!.docs.first
                        );
                        final originalEntry = TimetableEntry.fromFirestore(originalDoc);
                        Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => EditTimetableEntryScreen(uid: widget.uid, entry: originalEntry),
                        ));
                      },
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => EditTimetableEntryScreen(uid: widget.uid),
          ));
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}

